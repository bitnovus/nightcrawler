class Config(object):
     DEBUG = True
     SQLALCHEMY_DATABASE_URI='mysql://nightcrawleruser:aYmU63eswXv0@nightdb.ceoj8f0hdmgq.us-east-1.rds.amazonaws.com/routegraphdb'
