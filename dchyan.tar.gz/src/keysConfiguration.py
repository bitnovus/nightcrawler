class Config(object):
     DEBUG = True
     SQLALCHEMY_DATABASE_URI='postgresql://nddejdhuuqbsoj:NQw8yLPMVKdrsuXyYdoOHRIhsV@ec2-23-21-91-85.compute-1.amazonaws.com/dff4aenaimoanj'
